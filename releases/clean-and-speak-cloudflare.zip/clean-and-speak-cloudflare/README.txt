Clean & Speak — Cloudflare upload pack
======================================

1) pages-upload
   Open Cloudflare Dashboard → Workers & Pages → Create → Pages → Upload assets.
   Drop THIS folder (it already contains index.html).
   Live URL: https://clean-and-speak.pages.dev

2) workers-project
   Full site with the contact-form API.
   npm install
   npx wrangler login
   npx wrangler deploy
   Live URL: https://clean-and-speak.<your-subdomain>.workers.dev

Read HOW-TO-DEPLOY.md for details.
